-- ConstructFlow Ledger - initial Supabase schema
-- Run this entire file once in Supabase SQL Editor.

create extension if not exists pgcrypto;

create type public.app_role as enum ('owner', 'admin', 'accountant', 'storekeeper', 'site_engineer', 'viewer');
create type public.supplier_status as enum ('active', 'inactive');
create type public.site_status as enum ('planning', 'active', 'on_hold', 'completed');
create type public.receipt_destination as enum ('central_store', 'direct_to_site');
create type public.bill_type as enum ('purchase', 'client');
create type public.payment_status as enum ('unpaid', 'partially_paid', 'paid', 'overdue');
create type public.payment_direction as enum ('paid', 'received');
create type public.payment_mode as enum ('cash', 'bank_transfer', 'cheque', 'upi', 'card');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text,
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  gstin text,
  phone text,
  email text,
  address text,
  currency text not null default 'INR',
  default_tax_rate numeric(7,2) not null default 18 check (default_tax_rate >= 0),
  low_stock_alerts boolean not null default true,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.organization_members (
  organization_id uuid not null references public.organizations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role public.app_role not null default 'viewer',
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  primary key (organization_id, user_id)
);

create table public.suppliers (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  code text not null,
  name text not null,
  contact_person text,
  phone text,
  email text,
  gstin text,
  address text,
  opening_balance numeric(14,2) not null default 0,
  status public.supplier_status not null default 'active',
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (organization_id, code)
);

create table public.sites (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  code text not null,
  name text not null,
  client_name text,
  location text,
  site_engineer text,
  phone text,
  budget numeric(16,2) not null default 0 check (budget >= 0),
  start_date date,
  expected_end_date date,
  status public.site_status not null default 'planning',
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (organization_id, code)
);

create table public.materials (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  code text not null,
  name text not null,
  category text,
  unit text not null,
  standard_rate numeric(14,4) not null default 0 check (standard_rate >= 0),
  tax_rate numeric(7,2) not null default 0 check (tax_rate >= 0),
  reorder_level numeric(14,3) not null default 0 check (reorder_level >= 0),
  opening_stock numeric(14,3) not null default 0,
  storage_location text,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (organization_id, code)
);

create table public.material_receipts (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  receipt_no text not null,
  receipt_date date not null default current_date,
  supplier_id uuid not null references public.suppliers(id),
  supplier_invoice_no text,
  vehicle_no text,
  received_by text,
  destination public.receipt_destination not null default 'central_store',
  site_id uuid references public.sites(id),
  notes text,
  attachment_path text,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (organization_id, receipt_no),
  check ((destination = 'direct_to_site' and site_id is not null) or destination = 'central_store')
);

create table public.material_receipt_items (
  id uuid primary key default gen_random_uuid(),
  receipt_id uuid not null references public.material_receipts(id) on delete cascade,
  material_id uuid not null references public.materials(id),
  quantity numeric(14,3) not null check (quantity > 0),
  rate numeric(14,4) not null default 0 check (rate >= 0),
  tax_rate numeric(7,2) not null default 0 check (tax_rate >= 0),
  notes text,
  created_at timestamptz not null default now()
);

create table public.material_supplies (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  issue_no text not null,
  issue_date date not null default current_date,
  site_id uuid not null references public.sites(id),
  requested_by text,
  approved_by text,
  vehicle_no text,
  driver_name text,
  notes text,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (organization_id, issue_no)
);

create table public.material_supply_items (
  id uuid primary key default gen_random_uuid(),
  supply_id uuid not null references public.material_supplies(id) on delete cascade,
  material_id uuid not null references public.materials(id),
  quantity numeric(14,3) not null check (quantity > 0),
  rate numeric(14,4) not null default 0 check (rate >= 0),
  tax_rate numeric(7,2) not null default 0 check (tax_rate >= 0),
  notes text,
  created_at timestamptz not null default now()
);

create table public.bills (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  bill_no text not null,
  bill_type public.bill_type not null,
  bill_date date not null default current_date,
  due_date date,
  supplier_id uuid references public.suppliers(id),
  site_id uuid references public.sites(id),
  party_name text not null,
  reference_no text,
  discount numeric(14,2) not null default 0 check (discount >= 0),
  other_charges numeric(14,2) not null default 0 check (other_charges >= 0),
  notes text,
  status public.payment_status not null default 'unpaid',
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (organization_id, bill_no),
  check ((bill_type = 'purchase' and supplier_id is not null) or (bill_type = 'client' and site_id is not null))
);

create table public.bill_items (
  id uuid primary key default gen_random_uuid(),
  bill_id uuid not null references public.bills(id) on delete cascade,
  material_id uuid references public.materials(id),
  description text,
  quantity numeric(14,3) not null check (quantity > 0),
  rate numeric(14,4) not null default 0 check (rate >= 0),
  tax_rate numeric(7,2) not null default 0 check (tax_rate >= 0),
  created_at timestamptz not null default now()
);

create table public.payments (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  payment_no text not null,
  payment_date date not null default current_date,
  bill_id uuid not null references public.bills(id) on delete restrict,
  party_name text not null,
  direction public.payment_direction not null,
  amount numeric(14,2) not null check (amount > 0),
  mode public.payment_mode not null,
  reference text,
  notes text,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (organization_id, payment_no)
);

create table public.audit_logs (
  id bigint generated always as identity primary key,
  organization_id uuid,
  table_name text not null,
  record_id uuid,
  action text not null check (action in ('INSERT', 'UPDATE', 'DELETE')),
  old_data jsonb,
  new_data jsonb,
  performed_by uuid references auth.users(id),
  performed_at timestamptz not null default now()
);

create index suppliers_org_name_idx on public.suppliers (organization_id, name);
create index sites_org_status_idx on public.sites (organization_id, status);
create index materials_org_category_idx on public.materials (organization_id, category);
create index receipts_org_date_idx on public.material_receipts (organization_id, receipt_date desc);
create index receipt_items_material_idx on public.material_receipt_items (material_id);
create index supplies_org_date_idx on public.material_supplies (organization_id, issue_date desc);
create index supply_items_material_idx on public.material_supply_items (material_id);
create index bills_org_due_idx on public.bills (organization_id, due_date, status);
create index payments_org_date_idx on public.payments (organization_id, payment_date desc);

create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger profiles_set_updated_at before update on public.profiles for each row execute function public.set_updated_at();
create trigger organizations_set_updated_at before update on public.organizations for each row execute function public.set_updated_at();
create trigger suppliers_set_updated_at before update on public.suppliers for each row execute function public.set_updated_at();
create trigger sites_set_updated_at before update on public.sites for each row execute function public.set_updated_at();
create trigger materials_set_updated_at before update on public.materials for each row execute function public.set_updated_at();
create trigger receipts_set_updated_at before update on public.material_receipts for each row execute function public.set_updated_at();
create trigger supplies_set_updated_at before update on public.material_supplies for each row execute function public.set_updated_at();
create trigger bills_set_updated_at before update on public.bills for each row execute function public.set_updated_at();
create trigger payments_set_updated_at before update on public.payments for each row execute function public.set_updated_at();

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'full_name', new.email))
  on conflict (id) do nothing;
  return new;
end;
$$;

create trigger on_auth_user_created
after insert on auth.users
for each row execute function public.handle_new_user();

create or replace function public.is_org_member(org_id uuid)
returns boolean
language sql stable security definer set search_path = public
as $$
  select exists (
    select 1 from public.organization_members
    where organization_id = org_id and user_id = auth.uid() and is_active = true
  );
$$;

create or replace function public.has_org_role(org_id uuid, allowed_roles public.app_role[])
returns boolean
language sql stable security definer set search_path = public
as $$
  select exists (
    select 1 from public.organization_members
    where organization_id = org_id and user_id = auth.uid() and is_active = true and role = any(allowed_roles)
  );
$$;

create or replace function public.create_my_organization(org_name text)
returns uuid
language plpgsql security definer set search_path = public
as $$
declare new_org_id uuid;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  insert into public.organizations (name, created_by) values (org_name, auth.uid()) returning id into new_org_id;
  insert into public.organization_members (organization_id, user_id, role) values (new_org_id, auth.uid(), 'owner');
  return new_org_id;
end;
$$;

grant execute on function public.create_my_organization(text) to authenticated;

create or replace function public.refresh_bill_status(target_bill_id uuid)
returns void
language plpgsql security definer set search_path = public
as $$
declare total_amount numeric; paid_amount numeric; current_due date;
begin
  select coalesce(sum(i.quantity * i.rate * (1 + i.tax_rate / 100)), 0) + b.other_charges - b.discount, b.due_date
  into total_amount, current_due
  from public.bills b left join public.bill_items i on i.bill_id = b.id
  where b.id = target_bill_id
  group by b.id;

  select coalesce(sum(amount), 0) into paid_amount from public.payments where bill_id = target_bill_id;

  update public.bills set status = case
    when paid_amount >= total_amount and total_amount > 0 then 'paid'::public.payment_status
    when paid_amount > 0 then 'partially_paid'::public.payment_status
    when current_due is not null and current_due < current_date then 'overdue'::public.payment_status
    else 'unpaid'::public.payment_status
  end where id = target_bill_id;
end;
$$;

create or replace function public.payment_refresh_bill_trigger()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'DELETE' then perform public.refresh_bill_status(old.bill_id); return old; end if;
  perform public.refresh_bill_status(new.bill_id);
  if tg_op = 'UPDATE' and old.bill_id <> new.bill_id then perform public.refresh_bill_status(old.bill_id); end if;
  return new;
end;
$$;

create trigger payments_refresh_bill
after insert or update or delete on public.payments
for each row execute function public.payment_refresh_bill_trigger();

create or replace function public.prevent_negative_stock()
returns trigger language plpgsql security definer set search_path = public as $$
declare available numeric; org_id uuid;
begin
  select organization_id into org_id from public.material_supplies where id = new.supply_id;
  select m.opening_stock
      + coalesce((select sum(ri.quantity) from public.material_receipt_items ri join public.material_receipts r on r.id = ri.receipt_id where ri.material_id = new.material_id and r.organization_id = org_id and r.destination = 'central_store'), 0)
      - coalesce((select sum(si.quantity) from public.material_supply_items si join public.material_supplies s on s.id = si.supply_id where si.material_id = new.material_id and s.organization_id = org_id and si.id <> coalesce(new.id, gen_random_uuid())), 0)
  into available
  from public.materials m where m.id = new.material_id;
  if new.quantity > available then raise exception 'Insufficient stock. Available quantity: %', available; end if;
  return new;
end;
$$;

create trigger supply_item_stock_guard
before insert or update on public.material_supply_items
for each row execute function public.prevent_negative_stock();

create or replace function public.audit_row_changes()
returns trigger language plpgsql security definer set search_path = public as $$
declare org uuid; rid uuid;
begin
  org := coalesce((to_jsonb(new)->>'organization_id')::uuid, (to_jsonb(old)->>'organization_id')::uuid);
  rid := coalesce((to_jsonb(new)->>'id')::uuid, (to_jsonb(old)->>'id')::uuid);
  insert into public.audit_logs (organization_id, table_name, record_id, action, old_data, new_data, performed_by)
  values (org, tg_table_name, rid, tg_op, case when tg_op in ('UPDATE','DELETE') then to_jsonb(old) end, case when tg_op in ('INSERT','UPDATE') then to_jsonb(new) end, auth.uid());
  return coalesce(new, old);
end;
$$;

create trigger suppliers_audit after insert or update or delete on public.suppliers for each row execute function public.audit_row_changes();
create trigger sites_audit after insert or update or delete on public.sites for each row execute function public.audit_row_changes();
create trigger materials_audit after insert or update or delete on public.materials for each row execute function public.audit_row_changes();
create trigger receipts_audit after insert or update or delete on public.material_receipts for each row execute function public.audit_row_changes();
create trigger supplies_audit after insert or update or delete on public.material_supplies for each row execute function public.audit_row_changes();
create trigger bills_audit after insert or update or delete on public.bills for each row execute function public.audit_row_changes();
create trigger payments_audit after insert or update or delete on public.payments for each row execute function public.audit_row_changes();

create or replace view public.inventory_summary with (security_invoker = true) as
select
  m.id,
  m.organization_id,
  m.code,
  m.name,
  m.category,
  m.unit,
  m.standard_rate,
  m.reorder_level,
  m.opening_stock,
  coalesce(r.received_qty, 0) as received_qty,
  coalesce(s.supplied_qty, 0) as supplied_qty,
  m.opening_stock + coalesce(r.received_qty, 0) - coalesce(s.supplied_qty, 0) as available_qty,
  (m.opening_stock + coalesce(r.received_qty, 0) - coalesce(s.supplied_qty, 0)) * m.standard_rate as stock_value
from public.materials m
left join (
  select ri.material_id, sum(ri.quantity) received_qty
  from public.material_receipt_items ri
  join public.material_receipts mr on mr.id = ri.receipt_id
  where mr.destination = 'central_store'
  group by ri.material_id
) r on r.material_id = m.id
left join (
  select material_id, sum(quantity) supplied_qty
  from public.material_supply_items
  group by material_id
) s on s.material_id = m.id;

create or replace view public.bill_balances with (security_invoker = true) as
select
  b.id,
  b.organization_id,
  b.bill_no,
  b.bill_type,
  b.party_name,
  b.bill_date,
  b.due_date,
  b.status,
  coalesce(i.subtotal, 0) + coalesce(i.tax_amount, 0) + b.other_charges - b.discount as total_amount,
  coalesce(p.paid_amount, 0) as paid_amount,
  greatest(0, coalesce(i.subtotal, 0) + coalesce(i.tax_amount, 0) + b.other_charges - b.discount - coalesce(p.paid_amount, 0)) as balance_amount
from public.bills b
left join (
  select bill_id, sum(quantity * rate) subtotal, sum(quantity * rate * tax_rate / 100) tax_amount
  from public.bill_items group by bill_id
) i on i.bill_id = b.id
left join (
  select bill_id, sum(amount) paid_amount from public.payments group by bill_id
) p on p.bill_id = b.id;

alter table public.profiles enable row level security;
alter table public.organizations enable row level security;
alter table public.organization_members enable row level security;
alter table public.suppliers enable row level security;
alter table public.sites enable row level security;
alter table public.materials enable row level security;
alter table public.material_receipts enable row level security;
alter table public.material_receipt_items enable row level security;
alter table public.material_supplies enable row level security;
alter table public.material_supply_items enable row level security;
alter table public.bills enable row level security;
alter table public.bill_items enable row level security;
alter table public.payments enable row level security;
alter table public.audit_logs enable row level security;

create policy profiles_self_select on public.profiles for select using (id = auth.uid());
create policy profiles_self_update on public.profiles for update using (id = auth.uid()) with check (id = auth.uid());

create policy organizations_member_select on public.organizations for select using (public.is_org_member(id));
create policy organizations_admin_update on public.organizations for update using (public.has_org_role(id, array['owner','admin']::public.app_role[])) with check (public.has_org_role(id, array['owner','admin']::public.app_role[]));

create policy members_org_select on public.organization_members for select using (public.is_org_member(organization_id));
create policy members_owner_manage on public.organization_members for all using (public.has_org_role(organization_id, array['owner']::public.app_role[])) with check (public.has_org_role(organization_id, array['owner']::public.app_role[]));

create policy suppliers_member_select on public.suppliers for select using (public.is_org_member(organization_id));
create policy suppliers_accounts_write on public.suppliers for all using (public.has_org_role(organization_id, array['owner','admin','accountant']::public.app_role[])) with check (public.has_org_role(organization_id, array['owner','admin','accountant']::public.app_role[]));

create policy sites_member_select on public.sites for select using (public.is_org_member(organization_id));
create policy sites_admin_write on public.sites for all using (public.has_org_role(organization_id, array['owner','admin']::public.app_role[])) with check (public.has_org_role(organization_id, array['owner','admin']::public.app_role[]));

create policy materials_member_select on public.materials for select using (public.is_org_member(organization_id));
create policy materials_store_write on public.materials for all using (public.has_org_role(organization_id, array['owner','admin','storekeeper']::public.app_role[])) with check (public.has_org_role(organization_id, array['owner','admin','storekeeper']::public.app_role[]));

create policy receipts_member_select on public.material_receipts for select using (public.is_org_member(organization_id));
create policy receipts_store_write on public.material_receipts for all using (public.has_org_role(organization_id, array['owner','admin','storekeeper']::public.app_role[])) with check (public.has_org_role(organization_id, array['owner','admin','storekeeper']::public.app_role[]));
create policy receipt_items_member_select on public.material_receipt_items for select using (exists (select 1 from public.material_receipts r where r.id = receipt_id and public.is_org_member(r.organization_id)));
create policy receipt_items_store_write on public.material_receipt_items for all using (exists (select 1 from public.material_receipts r where r.id = receipt_id and public.has_org_role(r.organization_id, array['owner','admin','storekeeper']::public.app_role[]))) with check (exists (select 1 from public.material_receipts r where r.id = receipt_id and public.has_org_role(r.organization_id, array['owner','admin','storekeeper']::public.app_role[])));

create policy supplies_member_select on public.material_supplies for select using (public.is_org_member(organization_id));
create policy supplies_store_write on public.material_supplies for all using (public.has_org_role(organization_id, array['owner','admin','storekeeper','site_engineer']::public.app_role[])) with check (public.has_org_role(organization_id, array['owner','admin','storekeeper','site_engineer']::public.app_role[]));
create policy supply_items_member_select on public.material_supply_items for select using (exists (select 1 from public.material_supplies s where s.id = supply_id and public.is_org_member(s.organization_id)));
create policy supply_items_store_write on public.material_supply_items for all using (exists (select 1 from public.material_supplies s where s.id = supply_id and public.has_org_role(s.organization_id, array['owner','admin','storekeeper','site_engineer']::public.app_role[]))) with check (exists (select 1 from public.material_supplies s where s.id = supply_id and public.has_org_role(s.organization_id, array['owner','admin','storekeeper','site_engineer']::public.app_role[])));

create policy bills_member_select on public.bills for select using (public.is_org_member(organization_id));
create policy bills_accounts_write on public.bills for all using (public.has_org_role(organization_id, array['owner','admin','accountant']::public.app_role[])) with check (public.has_org_role(organization_id, array['owner','admin','accountant']::public.app_role[]));
create policy bill_items_member_select on public.bill_items for select using (exists (select 1 from public.bills b where b.id = bill_id and public.is_org_member(b.organization_id)));
create policy bill_items_accounts_write on public.bill_items for all using (exists (select 1 from public.bills b where b.id = bill_id and public.has_org_role(b.organization_id, array['owner','admin','accountant']::public.app_role[]))) with check (exists (select 1 from public.bills b where b.id = bill_id and public.has_org_role(b.organization_id, array['owner','admin','accountant']::public.app_role[])));

create policy payments_member_select on public.payments for select using (public.is_org_member(organization_id));
create policy payments_accounts_write on public.payments for all using (public.has_org_role(organization_id, array['owner','admin','accountant']::public.app_role[])) with check (public.has_org_role(organization_id, array['owner','admin','accountant']::public.app_role[]));

create policy audit_admin_select on public.audit_logs for select using (organization_id is not null and public.has_org_role(organization_id, array['owner','admin']::public.app_role[]));

-- Optional private bucket for receipt, bill and payment attachments.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('construction-documents', 'construction-documents', false, 10485760, array['application/pdf','image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;

create policy construction_docs_read on storage.objects for select to authenticated
using (bucket_id = 'construction-documents' and public.is_org_member((storage.foldername(name))[1]::uuid));
create policy construction_docs_insert on storage.objects for insert to authenticated
with check (bucket_id = 'construction-documents' and public.has_org_role((storage.foldername(name))[1]::uuid, array['owner','admin','accountant','storekeeper']::public.app_role[]));
create policy construction_docs_update on storage.objects for update to authenticated
using (bucket_id = 'construction-documents' and public.has_org_role((storage.foldername(name))[1]::uuid, array['owner','admin','accountant','storekeeper']::public.app_role[]));
create policy construction_docs_delete on storage.objects for delete to authenticated
using (bucket_id = 'construction-documents' and public.has_org_role((storage.foldername(name))[1]::uuid, array['owner','admin']::public.app_role[]));
